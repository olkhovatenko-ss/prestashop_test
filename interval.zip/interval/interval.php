<?php

if (!defined('_PS_VERSION_'))
  exit;

class Interval extends Module {

  public function __construct() {
    $this->name = 'interval'; //задаём имя нашего модуля
    $this->tab = 'others'; //задаём категорию модуля, в которой он будет отображаться в админке
    // например, 'front_office_features' - поместит модуль в раздел 'Модули для фронт-офиса'
    $this->version = '1.0.00'; //версия модуля, например "2.0b", "3.04 beta 5" или "0.67 (для разработчика)"
    $this->author = 'Sergey'; //имя автора
    $this->need_instance = 0; //открыть страницу настроек модуля сразу после установки или нет
    // если установить параметр = 1, то установка модуля может выполняться дольше
    $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_); //совместимость модуля с версией cms
    $this->bootstrap = true; //использовать инструмент bootstrap для построения элементов модуля, рекомендую установить true

    parent::__construct();

    $this->displayName = $this->l('Интервал'); //отображаемое имя модуля
    $this->description = $this->l('Интервал описание'); //отображаемое описание модуля

    $this->confirmUninstall = $this->l('Вы действительно хотите удалить модуль?'); //сообщение, при удалении модуля

    if (!Configuration::get('INTERVAL'))
      $this->warning = $this->l('Упс, произошла какая-то ошибка!'); //проверка на ошибки во время установки
  }

  public function install() {
    if (Shop::isFeatureActive()) //если несколько магазинов, то включаем модуль для всех
      Shop::setContext(Shop::CONTEXT_ALL);

    //установка модуля и привязка его к необходимым хукам, в которых он будет использован, создание конфигурации для модуля в базе данных
    if (!parent::install() || //установлен ли родительский класс
        !$this->registerHook('DisplayFooter') ||
        !Configuration::updateValue('PRICE_FROM', 9) ||
        !Configuration::updateValue('PRICE_TO', 36)
    )
      return false;

    return true;
  }

  //удаление модуля
  public function uninstall() {
    if (!parent::uninstall() ||
        !Configuration::deleteByName('PRICE_FROM') ||
        !Configuration::deleteByName('PRICE_TO')
    )
      return false;

    return true;
  }

  //в эту переменную будем записывать выводимый в админке текст
  private $_html = '';

  //функция getContent() вызывается при нажатии ссылки "настройки"
  public function getContent() {
    //Обработка отправленной формы
    $this->_postProcess();
    //Создаем код формы
    $this->_displayForm();
    //Возвращаем отображаемое содержимое
    return $this->_html;
  }

  private function _displayForm() {
    $this->_html .= '
        <form action="' . $_SERVER['REQUEST_URI'] . '" method="post">
          <fieldset>
            <legend>' . $this->l('Конфигурация модуля интервал') . '</legend>
              <label for="price_from">' . $this->l('Цена ОТ') . '</label>
              <div class="margin-form">
                <input id="price_from" type="number" step="0.01" name="price_from" value="' . Tools::getValue('price_from', Configuration::get('PRICE_FROM')) . '" />
                <p class="clear">' . $this->l('Поле для ввода Цена ОТ') . '</p>
              </div>
              <label for="price_to">' . $this->l('Цена ДО') . '</label>
              <div class="margin-form">
                <input id="price_to" type="number" step="0.01" name="price_to" value="' . Tools::getValue('price_to', Configuration::get('PRICE_TO')) . '" />
                <p class="clear">' . $this->l('Поле для ввода Цена ДО') . '</p>
              </div>
              <p class="center">
                <input class="button" type="submit" name="submitTutorial" value="' . $this->l('Сохранить') . '"/>
              </p>
            </fieldset>
          </form>
        ';
  }

  private function _postProcess() {
    //Проверяем отправлена ли форма
    if (Tools::isSubmit('submitTutorial')) {
      //Получаем значение полей формы
      $price_from = Tools::getValue('price_from');
      $price_to = Tools::getValue('price_to');
      //Проверяем валидность
      if (Validate::isFloat($price_from) && Validate::isFloat($price_to)) {
        //Сохраняем настройки
        Configuration::updateValue('PRICE_FROM', $price_from);
        Configuration::updateValue('PRICE_TO', $price_to);
        //Выводим сообщение об успешном сохранении
        $this->_html .= $this->displayConfirmation($this->l('Настройки обновлены.'));
      }
      else
        //Выводим сообщение об ошибке
        $this->_html .= $this->displayError($this->l('Неверные значения.'));
    }
  }

  public function hookDisplayFooter($params) {

    $price_from = Configuration::get('PRICE_FROM');
    $price_to = Configuration::get('PRICE_TO');

    $sql = new DbQuery();
    $sql->select('count(*)');
    $sql->from('product', 'p');
    $sql->where('p.price between ' . $price_from . ' and ' . $price_to);

    $product_count = Db::getInstance()->getValue($sql);

    $this->smarty->assign(array(
      'price_from' => $price_from,
      'price_to' => $price_to,
      'count' => $product_count
    ));

    return $this->display(__FILE__, 'interval.tpl');
  }

}
